// import React from "react";
// import { View } from "react-native";
// import Icon from "react-native-vector-icons/Ionicons";

// export default class App extends React.Component {
//   componentDidMount() {
//     Font.loadAsync({
//       'open-sans-bold': require('./assets/fonts/OpenSans-Bold.ttf'),
//     });
   
//   }
 
// )};