import CustomTabNavigator from "./CustomTabNavigator";

export default CustomTabNavigator;
