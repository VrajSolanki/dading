import React, { Component } from 'react';
import { createMaterialTopTabNavigator, createBottomTabNavigator } from "react-navigation";
import { Text, View, StyleSheet, Platform } from 'react-native';
import { Ionicons } from "@expo/vector-icons";

import BottomNavigation, {
  IconTab
} from 'react-native-material-bottom-navigation'
 

import PageA from "../../views/Home/PageA";
import PageB from "../../views/Home/PageB";
// import PageC from "../../views/Home/PageC";


export class Ding_Icon extends React.Component {
  async componentWillMount() {
    await Expo.Font.loadAsync({
      Roboto: require("../../assets/fonts/Roboto/Roboto-Regular.ttf"),
      Roboto_medium: require("../../assets/fonts/Roboto/Roboto-Medium.ttf"),
      Ionicons: require("@expo/vector-icons/fonts/Ionicons.ttf")
    });
    this.setState({ loading: false });
  }

  tabs = [
    {
      key: 'games',
      icon: 'gamepad-variant',
      label: 'Games',
      barColor: '#388E3C',
      pressColor: 'rgba(255, 255, 255, 0.16)'
    },
    {
      key: 'movies-tv',
      icon: 'movie',
      label: 'Movies & TV',
      barColor: '#B71C1C',
      pressColor: 'rgba(255, 255, 255, 0.16)'
    },
    {
      key: 'music',
      icon: 'music-note',
      label: 'Music',
      barColor: '#E64A19',
      pressColor: 'rgba(255, 255, 255, 0.16)'
    }
  ]
 
  renderIcon = icon => ({ isActive }) => (
    <Ionicons size={24} color="white" name={icon} />
  )
 
  renderTab = ({ tab, isActive }) => (
    <IconTab
      isActive={isActive}
      key={tab.key}
      label={tab.label}
      renderIcon={this.renderIcon(tab.icon)}
    />
  )
  render() {
    return (
      <View style={{ flex: 1 }}>

      <View style={styles.container}>
          <Text style = {styles.ding}>DING!</Text>
      </View>
      <View style={{ flex: 1 }}>
        {/* Your screen contents depending on current tab. */}
      </View>
      <BottomNavigation
        onTabPress={newTab => this.setState({ activeTab: newTab.key })}
        renderTab={this.renderTab}
        tabs={this.tabs}
      />
    </View>
    );
  }
}

const CustomTabNavigator = createBottomTabNavigator(

  {
    PageA: {
      navigationOptions: {
        tabBarLabel:<Ionicons name = {
          Platform.OS === "ios" ? "ios-notifications" : "md-notifications"
        } />

      },
      screen: PageA
    },
    PageB: {
      navigationOptions: {
        tabBarLabel: "PageB"
      },
      screen: PageB
    },
     PageC: {
      navigationOptions: {
        tabBarLabel: <Ding_Icon />
      },
      screen: PageB
    },
     PageD: {
      navigationOptions: {
        tabBarLabel: "PageB"
      },
      screen: PageB
    },
     PageE: {
      navigationOptions: {
        tabBarLabel: "PageB"
      },
      screen: PageB
    }
  },
  {
    tabBarPosition: "bottom"
  }
);

const styles = StyleSheet.create({
  container: {
    justifyContent: 'center',
    alignItems: 'center',
    backgroundColor: 'white',
    borderRadius: 35,
    width: 70,
    height: 70,
    bottom: 5,
    
    margin: 5,
    borderColor: '#FEC107'
  },
  ding: {
     transform: [{ rotate: '330deg'}],
     fontWeight: 'bold',
     fontSize: 20,
     color: '#D6684A'
  }
});
export default CustomTabNavigator;
