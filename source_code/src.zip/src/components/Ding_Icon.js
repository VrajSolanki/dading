import React, { Component } from 'react';
import { Text, View, StyleSheet, Image } from 'react-native';
import { Icon } from 'expo';

export default class Ding_Icon extends React.Component {
  render() {
    return (
      <View style={styles.container}>
          <Text style = {styles.ding}>DING!</Text>
      </View>
    );
  }
}

