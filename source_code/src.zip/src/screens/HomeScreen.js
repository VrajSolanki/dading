import React from 'react';

//import Icon from 'react-native-vector-icons/MaterialIcons';
import {   Image,
  Platform,
  ScrollView,
  StyleSheet,
  Text,
  TouchableOpacity,
  View,
  FlatList, Button} from 'react-native';
import HeaderButtons, { HeaderButton, Item } from 'react-navigation-header-buttons';
import Dings from '../components/Dings'
import Topics from '../components/Topics'
import Recommendations from '../components/Recommendations'
import CustomTabNavigator from "../components/CustomTabNavigator";
import CustomHeader from "../components/CustomHeader";
const DisableableHeaderButton = props => (
  <HeaderButton
    {...props}
    background={Touchable.Ripple('white', true)}
    IconComponent={Ionicons}
    iconSize={35}
    color="white"
  />
);

export default class HomeScreen extends React.Component {
  // async componentWillMount() {
  //   await Expo.Font.loadAsync({
  //     Roboto: require("../assets/fonts/Roboto/Roboto-Regular.ttf"),
  //     Roboto_medium: require("../assets/fonts/Roboto/Roboto-Medium.ttf"),
  //     Ionicons: require("@expo/vector-icons/fonts/Ionicons.ttf")
  //   });
  //   this.setState({ loading: false });
  // }
  static navigationOptions = {
    headerStyle: {
      backgroundColor: '#FEC107',
    },
    headerTintColor: '#fff',
    headerTitleStyle: {
      fontWeight: 'bold',
    },
    headerRight: (
      <HeaderButtons HeaderButtonComponent={DisableableHeaderButton}>
        <Item title="search" iconName="ios-search" onPress={() => alert('search')} disabled />
        <Item title="select" iconName="ios-navigate" onPress={() => alert('select')} />
      </HeaderButtons>
    ),
      headerLeft: (
        <HeaderButtons HeaderButtonComponent={DisableableHeaderButton}>
          <Item title="search" iconName="ios-menu" onPress={() => alert('search')} disabled />
          <Item title="HOME" />
        </HeaderButtons>
        ),
  };
  static router = CustomTabNavigator.router;

  render() {
    return (
      <View style={{flex: 1}}>
      <View>
        <CustomHeader navigation={this.props.navigation} />
        {/* <CustomTabNavigator navigation={this.props.navigation} /> */}
      </View>
    <ScrollView>
    <View style = {styles.container}>
      <View  style = {styles.box}>

        <Text style = {styles.header}>
            Dings
        </Text>

        <Text style = {styles.tagline}>
           Let's get dinging
        </Text>

          <ScrollView contentContainerStyle={styles.scrollContent}
          horizontal={true}
          showsHorizontalScrollIndicator={false}
          showsVerticalScrollIndicator={false}>
                  <Dings interest = "football" topic = "t1"/>
                  <Dings interest = "football" topic = "t2"/>
                  <Dings interest = "football" topic = "t3"/>
                  <Dings interest = "football" topic = "t4"/>
                  <Dings interest = "football" topic = "t1"/>
                  <Dings interest = "football" topic = "t1"/>
            </ScrollView>

            <ScrollView contentContainerStyle={styles.scrollContent}
            horizontal={true}
            showsHorizontalScrollIndicator={false}
            showsVerticalScrollIndicator={false}>
            <Dings interest = "football" topic = "t1"/>
            <Dings interest = "football" topic = "t2"/>
            <Dings interest = "football" topic = "t3"/>
            <Dings interest = "football" topic = "t4"/>
            <Dings interest = "football" topic = "t1"/>
            <Dings interest = "football" topic = "t1"/>
              </ScrollView>
      </View>

      <View  style = {styles.box}>
        <Text style = {styles.header}>
          My Topics
        </Text>
          <ScrollView contentContainerStyle={styles.scrollContent}
          horizontal={true}
          showsHorizontalScrollIndicator={false}
          showsVerticalScrollIndicator={false}>
                  <Topics topicType ="football" />
                  <Topics topicType ="cricket" />
                  <Topics topicType ="painting" />
                  <Topics topicType ="football" />
                  <Topics topicType ="game" />
            </ScrollView>
      </View>

      <View  style = {styles.box}>
        <Text style = {styles.header}>
          Recommendations!
        </Text>
          <ScrollView contentContainerStyle={styles.scrollContent}
          horizontal={true}
          showsHorizontalScrollIndicator={false}
          showsVerticalScrollIndicator={false}>
          <Topics topicType ="football" />
          <Topics topicType ="cricket" />
          <Topics topicType ="painting" />
          <Topics topicType ="football" />
          <Topics topicType ="game" />
            </ScrollView>
      </View>


      <View  style = {styles.box}>
        <Text style = {styles.header}>
          Tren-ding-ers!
        </Text>
          <ScrollView contentContainerStyle={styles.scrollContent}
          horizontal={true}
          showsHorizontalScrollIndicator={false}
          showsVerticalScrollIndicator={false}>
          <Dings interest = "football" topic = "t1"/>
          <Dings interest = "football" topic = "t2"/>
          <Dings interest = "football" topic = "t3"/>
          <Dings interest = "football" topic = "t4"/>
          <Dings interest = "football" topic = "t1"/>
          <Dings interest = "football" topic = "t1"/>
            </ScrollView>

            <ScrollView contentContainerStyle={styles.scrollContent}
            horizontal={true}
            showsHorizontalScrollIndicator={false}
            showsVerticalScrollIndicator={false}>
            <Dings interest = "football" topic = "t1"/>
            <Dings interest = "football" topic = "t2"/>
            <Dings interest = "football" topic = "t3"/>
            <Dings interest = "football" topic = "t4"/>
            <Dings interest = "football" topic = "t1"/>
            <Dings interest = "football" topic = "t1"/>
              </ScrollView>
      </View>
      </View>
      
      </ScrollView>
      <View>
        <CustomTabNavigator navigation={this.props.navigation} />
      </View>
      </View>
    );
  }
}

const styles = StyleSheet.create({
  container: {
    backgroundColor: '#EEEEEE',
  },
  ding: {
    padding: 20
  },
  scrollContent: {
    flexDirection: 'row',   // arrange posters in rows
  },
  staticContent: {
    flexDirection: 'row',   // arrange posters in rows
    flexWrap: 'wrap'      //// allow multiple rows
  },
  header: {
    fontSize:20,
    textAlign: 'center',
    fontWeight: 'bold'
  },
  box: {
    backgroundColor: "white",
    marginBottom: 4,
    padding: 6
  },
  tagline: {
    fontSize: 16,
    left: 155,
    fontStyle: 'italic',
    color: 'grey'
  }


});
